# Final-era census

| Family | Games and roles | Terminal outcomes | Recorded own actions | Own actions | Errors |
| --- | --- | --- | --- | ---: | ---: |
| bargaining | 19; player_1=9, player_2=10 | 19 agreements | 49 offers; 40 rejects; 8 accepts | 97 | 0 |
| negotiation | 19; seller=10, buyer=9 | 13 agreements; 3 walks; 3 no-deals | 10 initial offers; 171 rejects or counters; 7 accepts; 2 own walks | 190 | 0 |
| persuasion | 25; seller=11, buyer=14 | 25 completed games | buyer yes/no 233/47; binary seller yes/no 50/30; text seller yes/no 108/32 | 500 | 0 |
